module.exports = {
    admin: {email: 'emailId', password: 'Password'}
    //  admin: {email: 'service@ecocloud.com', user: 'solone', password: '9huyGQeNiHfbHhurdPeOqT7l'}
 }